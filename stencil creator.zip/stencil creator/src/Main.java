import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
        BufferedImage img = ImageIO.read(new File("Reference Images/mountain lake stars.png"));
        JFrame frame = new JFrame("Altered Image");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        ImgPanel imgPanel = new ImgPanel(img, 1, 4, 10, 80, true);
        frame.add(imgPanel);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

}