import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class ArrowKeyListener implements KeyListener {

    private ImgPanel panel;

    public ArrowKeyListener(ImgPanel panel) {
        this.panel = panel;
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int keyCode = e.getKeyCode();
        if(e.getKeyChar()=='v') {
            panel.viewStencils();
            return;
        }
        if(e.getKeyChar()=='x') {
            panel.exportStencils();
            return;
        }
        switch (keyCode) {
            case KeyEvent.VK_UP:
                panel.changeTolerance(panel.getdT());
                break;
            case KeyEvent.VK_DOWN:
                panel.changeTolerance(-panel.getdT());
                break;
            case KeyEvent.VK_LEFT:
                if(panel.isViewing()) panel.decrementStencilIndex();
                else panel.changeTolerance(-1);
                break;
            case KeyEvent.VK_RIGHT:
                if(panel.isViewing()) panel.incrementStencilIndex();
                else panel.changeTolerance(1);
                break;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        // Not used in this example
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // Not used in this example
    }
}