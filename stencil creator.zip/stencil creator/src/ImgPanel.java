import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.*;

public class ImgPanel extends JPanel {

    private int tolerance, stencilIndex;
    private final int numColors, blockR, dT, maxT, minT, scale;
    private Color[][] alteredImg;
    private BufferedImage img;
    private BufferedImage[] stencilImgs;
    private boolean fill = true, viewing = false, exReady = false, first = true;
    private ArrayList<Color> exportList;

    public ImgPanel(BufferedImage img, int scale, int numColors, int minT, int maxT, boolean autoTolerance) {
        super();
        this.img = img; this.scale = scale; this.numColors = numColors; this.minT = minT; this.maxT = maxT;
        this.setPreferredSize(new Dimension(img.getWidth()*scale, img.getHeight()*scale));
        this.setVisible(true);
        this.setBackground(Color.WHITE);
        addKeyListener(new ArrowKeyListener(this));
        setFocusable(true);
        exportList = new ArrayList<>();
        blockR = 5; dT = 5;
        tolerance = ((autoTolerance)?minT:(minT+maxT)/2);
        alteredImg = alterImg(img, fill, autoTolerance);
        repaint();
    }

    public void newImage(Color[][] newImg) {
        alteredImg = newImg;
        repaint();
    }

    private Color[][] alterImg(BufferedImage img, boolean fill, boolean auto) {

        double minPSum = 3.0;
        int bestTolerance = -1;

        for(tolerance = ((auto)?minT:((first)?(minT+maxT)/2:tolerance)); tolerance<=maxT; tolerance++) {

            if(first) first = false;
            HashMap<Color, ArrayList<int[]>> colorPts = new HashMap<>(), ncPts = new HashMap<>();

            for(int i = 0; i < img.getWidth(); i++) {
                for(int j = 0; j < img.getHeight(); j++) {
                    Color current = new Color(img.getRGB(i, j));
                    Color closest = closeKey(colorPts.keySet(), current, tolerance, false);
                    if(closest == null) {
                        ArrayList<int[]> pt = new ArrayList<>();
                        pt.add(new int[]{i, j});
                        colorPts.put(current, pt);
                    } else colorPts.get(closest).add(new int[]{i, j});
                }
            }

            for(Color key : colorPts.keySet()) {
                ArrayList<int[]> pts = colorPts.get(key);
                Color nc = avgColor(pts, img);
                if(ncPts.containsKey(nc)) ncPts.get(nc).addAll(pts);
                else ncPts.put(nc, pts);
            }

            boolean found = true;
            while(found) {
                Set<Color> keys = ncPts.keySet();
                found = false;
                for(Color current : keys) {
                    Color closest = closeKey(keys, current, tolerance, true);
                    if(closest != null) {
                        found = true;
                        int si = ncPts.get(current).size(), sj = ncPts.get(closest).size(), totalSize = si + sj;
                        Color merged = new Color((current.getRed()*si+closest.getRed()*sj)/totalSize,
                                (current.getGreen()*si+closest.getGreen()*sj)/totalSize, (current.getBlue()*si+closest.getBlue()*sj)/totalSize);
                        ArrayList<int[]> locs = ncPts.get(current);
                        locs.addAll(ncPts.get(closest));
                        ncPts.put(merged, locs);
                        if(!current.equals(merged)) ncPts.remove(current);
                        if(!closest.equals(merged)) ncPts.remove(closest);
                        break;
                    }
                }
            }

            ArrayList<Map.Entry<Color,ArrayList<int[]>>> sortedPts = new ArrayList<>(ncPts.entrySet());
            sortedPts.sort(Comparator.comparingInt((Map.Entry<Color, ArrayList<int[]>> entry) -> entry.getValue().size()).reversed());
            exportList.clear();
            for(int i = 0; i < Math.min(numColors, sortedPts.size()); i++) exportList.add(sortedPts.get(i).getKey());
            System.out.println("Tolerance: " + tolerance + ", Colors: " + exportList.size());
            Color[][] alteredImg = new Color[img.getWidth()][img.getHeight()];
            for(Color c : exportList)
                for(int[] coord : ncPts.get(c))
                    alteredImg[coord[0]][coord[1]] = c;

            int fillCount = 0;
            if(fill) {
                for(int i = 0; i < alteredImg.length; i++) {
                    for(int j = 0; j < alteredImg[0].length; j++) {
                        if(alteredImg[i][j]!=null) continue;
                        int tempR = blockR, dR = 5; Color mostCommon = null;
                        boolean first = true;
                        while(mostCommon==null) {
                            HashMap<Color, Integer> colorCount = new HashMap<>();
                            int maxCount = -1;
                            for(int k = Math.max(0,i-tempR); k<Math.min(img.getWidth(),i+tempR+1); k++) {
                                for(int l = Math.max(0,j-tempR); l<Math.min(img.getHeight(),j+tempR+1); l++) {
                                    if(!first&&k>=i-tempR+dR&&k<=i+tempR-dR&&l>=j-tempR+dR&&l<=j+tempR-dR) continue;
                                    Color temp = alteredImg[k][l];
                                    if(temp!=null) {
                                        int tempCount = colorCount.getOrDefault(temp, 0) + 1;
                                        colorCount.put(temp, tempCount);
                                        if(tempCount > maxCount) {
                                            maxCount = tempCount;
                                            mostCommon = temp;
                                        }
                                    }
                                }
                            }
                            first=false;
                            tempR += dR;
                        }
                        alteredImg[i][j] = mostCommon;
                        if(auto) fillCount++;
                    }
                }
            }

            if(!auto) return alteredImg;
            newImage(alteredImg);

            double currentPSum = (double)fillCount/(img.getWidth()*img.getHeight())+(double)(numColors-exportList.size())/numColors;
            if(currentPSum<minPSum) {
                minPSum = currentPSum;
                bestTolerance = tolerance;
                System.out.println("Best Tolerance: " + bestTolerance + ", " + minPSum);
            }

        }

        tolerance = bestTolerance;
        return alterImg(img, true, false);

    }

    private Color avgColor(ArrayList<int[]> pts, BufferedImage img) {
        int r = 0, g = 0, b = 0;
        for(int[] pt : pts) {
            Color current = new Color(img.getRGB(pt[0], pt[1]));
            r+=current.getRed(); g+= current.getGreen(); b+=current.getBlue();
        }
        r/=pts.size(); g/=pts.size(); b/=pts.size();
        return new Color(r, g, b);
    }

    private Color closeKey(Set<Color> keys, Color c, int tolerance, boolean skipSelf) {
        if(keys == null || keys.isEmpty()) return null;
        int minDiff = 800;
        Color closest = null;
        for(Color key : keys) {
            int keyDiff = rgbDiff(key, c);
            if(keyDiff == 0 && skipSelf) continue;
            if(keyDiff < minDiff) {
                minDiff = keyDiff;
                closest = key;
                if(keyDiff == 0) break;
            }
        }
        if(minDiff <= tolerance*3) return closest;
        return null;
    }

    private int rgbDiff(Color c1, Color c2) {
        return (Math.abs(c1.getRed()-c2.getRed())+Math.abs(c1.getGreen()-c2.getGreen())+Math.abs(c1.getBlue()-c2.getBlue()));
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2d = (Graphics2D) g, stencilGraphics=null;
        BufferedImage stencilImg=null;
        if(viewing) {
            if(stencilIndex>=exportList.size()) {
                for(int i = 0; i <= stencilIndex-exportList.size(); i++) g2d.drawImage(stencilImgs[i], null, 0, 0);
                g2d.dispose();
                return;
            }
            if(stencilImgs[stencilIndex]!=null) {
                g2d.drawImage(stencilImgs[stencilIndex], null, 0, 0);
                g2d.dispose();
                return;
            }
            stencilImg = new BufferedImage(img.getWidth(),img.getHeight(),BufferedImage.TYPE_INT_ARGB);
            stencilImgs[stencilIndex]=stencilImg;
            stencilGraphics = stencilImg.createGraphics();
            stencilGraphics.setBackground(null);
        }
        for(int i = 0; i < alteredImg.length; i++) {
            for(int j = 0; j < alteredImg[0].length; j++) {
                Color current = alteredImg[i][j];
                if(!viewing || current.equals(exportList.get(stencilIndex))) {
                    ((viewing)?stencilGraphics:g2d).setColor(alteredImg[i][j]);
                    ((viewing)?stencilGraphics:g2d).fillRect(i*scale, j*scale, scale, scale);
                }
//                if(current==null) System.out.println("EMPTY");
            }
        }
        if(viewing) {
            g2d.drawImage(stencilImg, null, 0, 0);
            if(stencilIndex==exportList.size()-1) exReady=true;
            stencilGraphics.dispose();
        }
        g2d.dispose();
    }

    public void changeTolerance(int change) {
        if(change==0||(change>0&&tolerance==maxT)||(change<0&&tolerance==minT)) return;
        tolerance=Math.max(Math.min(tolerance+change,maxT),minT);
        System.out.println(tolerance);
        Color[][] newImg = alterImg(img, fill, false);
        newImage(newImg);
    }

    public int getdT() {return this.dT;}
    public boolean isViewing() {return this.viewing;}

    public void exportStencils() {
        if(!viewing||!exReady) {
            System.out.println("EXPORT FAILED");
            return;
        }
        for(int i=0; i<exportList.size(); i++) {
            File file = new File("Stencils/Stencil"+(i+1)+".png");
            try {
                ImageIO.write(stencilImgs[i], "png", file);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        System.out.println("EXPORT SUCCESSFUL");
    }

    public void viewStencils() {
        System.out.println("VIEWING STENCILS\nTOLERANCE: "+tolerance+", COLORS: "+exportList.size());
        viewing = true;
        stencilIndex = 0;
        stencilImgs=new BufferedImage[exportList.size()];
        repaint();
    }

    public void incrementStencilIndex() {
        if(this.stencilIndex ==2*exportList.size()-1) return;
        this.stencilIndex++;
        if(stencilIndex <exportList.size()) System.out.println("COLOR " + (stencilIndex +1));
        else System.out.println("COLORS 1-" + (stencilIndex +1-exportList.size()));
        repaint();
    }

    public void decrementStencilIndex() {
        if(this.stencilIndex ==0) return;
        this.stencilIndex--;
        if(stencilIndex <exportList.size()) System.out.println("COLOR " + (stencilIndex +1));
        else System.out.println("COLORS 1-" + (stencilIndex +1-exportList.size()));
        repaint();
    }

}
